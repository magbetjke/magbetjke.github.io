<?php
    echo "<filelist>\n";
   
    $folder = ".";
    $only_dirs = false;

    if (isset($_REQUEST['dir']))
    {
       $folder = $_REQUEST['dir'];
    }
    if (isset($_REQUEST['only_dirs']))
    {
       $only_dirs = true;
    }
    
    if (substr($folder, -1) === "/"){
        $pattern = $folder."*";
    } else {
        $pattern = $folder."/*";
    }
    

    foreach (glob($pattern) as $filename) 
    {
        ($f = fopen($filename, "r")) or die("error");
        fclose($f);
        $isdir = is_dir($filename);
        if ($only_dirs && !$isdir) continue;
        $short = basename($filename);
        $tp = ($isdir ? "dir" : "file");
        $mtime = filemtime($filename);
        echo "<file name=\"$filename\" short=\"$short\" type=\"$tp\" mtime=\"$mtime\"/>\n";
    }
    echo "</filelist>\n";
?>
