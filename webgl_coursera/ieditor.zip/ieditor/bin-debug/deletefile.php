<?php
$filename = $_REQUEST['f'];
unlink($filename);		

echo 'OK';
?>