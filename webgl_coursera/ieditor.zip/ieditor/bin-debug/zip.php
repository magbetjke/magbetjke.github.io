<?php

exec('rm maps.zip');
exec('zip -r maps.zip '.$_GET["p"].'/maps/*.xml');
header('Location: maps.zip');

?>