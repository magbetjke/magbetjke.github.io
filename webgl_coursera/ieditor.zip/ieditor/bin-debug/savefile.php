<?php

require_once('common.php');

$name = $_REQUEST['name'];
$data = stripslashes($_REQUEST['data']);

if (!check_path($name) || !match_file($name)) {
	reply("error", "File name is not valid.");
} else if (strlen($data) > 0) {
	$file = fopen ($name, "w");
	if (!$file) 
	{
		reply("error", "Unable to open file '" . $name . "' for writing.");
	    exit;
	}
	fwrite ($file, $data);
	fclose($file);
	reply("ok", "Successfully saved.");
} else {
	reply("error", "No data received.");
}
?>