<?php
   $p = basename(dirname(__FILE__));
   header("Location: ..?p=".$p);
?>