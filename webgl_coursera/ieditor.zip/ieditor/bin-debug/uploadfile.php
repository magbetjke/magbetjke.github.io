<?php

$tempFile = $_FILES['Filedata']['tmp_name'];
$fileName = $_FILES['Filedata']['name'];
$fileSize = $_FILES['Filedata']['size'];
$dir = $_REQUEST['dir'];

move_uploaded_file($tempFile, $dir.'/'.$fileName);

echo 'OK';

?>