<?php

// Operations with directories.

require_once('common.php');

$action = $_REQUEST['action'];

if ($action === "create") {
    $name = $_REQUEST['name'];
    if (match_dir($name) && check_path($name)) {
        if (file_exists($name)) {
            reply("error", "Already exists: " . $name);
        } else if (mkdir($name)) {
            reply("ok", "Successfully created directory: " . $name);
        } else {
            reply("error", "Cannot create directory: " . $name);
        }
    } else {
        reply("error", "Please, specify a valid directory name.");
    }
} else if ($action === "remove") {
    $name = $_REQUEST['name'];
    if (is_dir($name) && check_path($name)) {
        if (rmdir($name)) {
            reply("ok", "Successfully removed directory: " . $name);
        } else {
            reply("error", "Failed to remove dir: " . $name. " Probably it's not empty.");
        }
    } else {
        reply("error", "Not a valid directory name: " . $name);
    }
} else if ($action === "rename" || $action === "copy") {
    $from = $_REQUEST['from'];
    $to   = $_REQUEST['to'];
    if (is_dir($from)) {
        $match = match_dir($to);
    } else {
        $match = match_file($to);
    }

    if (!check_path($from) || !check_path($to) || !$match) {
        reply("error", "Please, specify a valid name.");
    } else if (file_exists($to)){
        reply("error", "Destination already exists.");
    } else {
        if ($action === "rename") {
            $result = rename($from, $to);
        } else {
            $result = copy($from, $to);
        }
        if ($result) {
            reply("ok", "Success " . $action . " from " . $from . " to ". $to);
        } else {
            reply("error", "Failed to " . $action . " from " . $from . " to " . $to);
        }
    }
}

?>