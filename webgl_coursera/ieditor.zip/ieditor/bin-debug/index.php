<?php

$n = rand(1, 10000);	
$src = 'Editor.swf?nocache='.$n;
$projectDir = "";	
if(isset($_GET["p"])) { 
	$projectDir = $_GET["p"];
}

echo
'
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
<META HTTP-EQUIV="expires" CONTENT="0">
<style type="text/css">
* {
   width: 100%;
   height: 100%;
   margin: 0;
   padding: 0;
   overflow: hidden;
}
</style>
</head>
<body>
<object>
<param name="movie" value="'.$src.'">
<embed src="'.$src.'&projectDir='.$projectDir.'">
</embed>
</object>
</body>
</html>
';

?>