<?php

$filename = $_REQUEST['f'];
$handle = fopen($filename, "r");
$contents = fread($handle, filesize($filename));
fclose($handle);

echo '<form method="post" action="savefile.php?f='.$filename.'">
		<textarea cols="100" rows="40" id="xmldata" name="xmldata">'.$contents.'</textarea>
		<br><br><input type="submit"/>';
		
?>