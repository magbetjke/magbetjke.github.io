<?php

function reply($status, $message) {
    echo '<result status="' . $status . '">' . $message . '</result>';
}

function check_path($path) {
    return strpos($path, '//') === false &&
           strpos($path, '/./') === false &&
           strpos($path, '/../') === false;
}

function match_dir($dirname) {
    return preg_match('/^[_!\-A-Za-z0-9\/]*$/', $dirname);
}

function match_file($filename) {
    return preg_match('/^[_!\-A-Za-z0-9\/\.]*$/', $filename);
}

?>